import argparse
import numpy as np
import librosa
import soundfile as sf


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    audio, sample_rate = librosa.load(args.input, sr=None, mono=False)
    mono = audio if audio.ndim == 1 else np.mean(audio, axis=0)
    hop = 512
    chroma = librosa.feature.chroma_cqt(y=mono, sr=sample_rate, hop_length=hop)
    normalized = chroma / (chroma.sum(axis=0, keepdims=True) + 1e-9)
    entropy = -np.sum(normalized * np.log(normalized + 1e-9), axis=0)
    lead_chroma = 1.0 - (entropy - entropy.min()) / (entropy.max() - entropy.min() + 1e-9)
    onsets = librosa.onset.onset_strength(y=mono, sr=sample_rate, hop_length=hop)
    window = max(1, int(sample_rate / hop))
    density = np.convolve(onsets, np.ones(window) / window, mode="same")
    lead_onsets = 1.0 - (density - density.min()) / (density.max() - density.min() + 1e-9)
    centroid = librosa.feature.spectral_centroid(y=mono, sr=sample_rate, hop_length=hop)[0]
    brightness = (centroid - centroid.min()) / (centroid.max() - centroid.min() + 1e-9)
    length = min(len(lead_chroma), len(lead_onsets), len(brightness))
    score = 0.5 * lead_chroma[:length] + 0.3 * lead_onsets[:length] + 0.2 * brightness[:length]
    smoothing = max(1, int(sample_rate / hop / 2))
    score = np.convolve(score, np.ones(smoothing) / smoothing, mode="same")
    lead = 1.0 / (1.0 + np.exp(-8.0 * (score - 0.5)))
    samples = np.arange(mono.shape[-1])
    lead = np.interp(samples, np.arange(length) * hop, lead).astype(np.float32)
    rhythm = 1.0 - lead
    if audio.ndim == 2:
        lead_audio, rhythm_audio = audio * lead[np.newaxis, :], audio * rhythm[np.newaxis, :]
        lead_audio, rhythm_audio = lead_audio.T, rhythm_audio.T
    else:
        lead_audio, rhythm_audio = audio * lead, audio * rhythm
    sf.write(f"{args.output_dir}/guitar_lead.wav", lead_audio, sample_rate)
    sf.write(f"{args.output_dir}/guitar_rhythm.wav", rhythm_audio, sample_rate)


if __name__ == "__main__":
    main()
